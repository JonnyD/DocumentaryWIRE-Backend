<?php

namespace App\Traits;

trait Sluggable
{

}
<?php

namespace App\Entity;

use Gedmo\Blameable\Traits\Blameable;
use Gedmo\SoftDeleteable\Traits\SoftDeleteable;
use App\Traits\Timestampable;

class Poster
{

    use Timestampable;
    use Blameable;
    use SoftDeleteable;
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="text")
     * @Gedmo\Versioned
     */
    private $imageLink;

    private $documentary;

}
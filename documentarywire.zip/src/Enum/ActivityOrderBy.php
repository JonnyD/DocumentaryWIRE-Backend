<?php

namespace App\Enum;

class ActivityOrderBy
{
    const CREATED_AT = "createdAt";
    const GROUP_NUMBER = "groupNumber";
}
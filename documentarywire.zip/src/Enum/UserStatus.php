<?php

namespace App\Enum;

class UserStatus
{
    const ACTIVE = 1;
    const INACTIVE = 2;
}
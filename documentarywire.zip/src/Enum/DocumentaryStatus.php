<?php

namespace App\Enum;

class DocumentaryStatus
{
    const PUBLISH = "publish";
    const DRAFT = "draft";
    const PENDING = "pending";
}
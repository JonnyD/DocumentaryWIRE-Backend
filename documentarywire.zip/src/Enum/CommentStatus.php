<?php

namespace App\Enum;

class CommentStatus
{
    const PUBLISH = 1;
    const PENDING = 2;
}
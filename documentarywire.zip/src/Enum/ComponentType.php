<?php

namespace App\Enum;

class ComponentType
{
    const DOCUMENTARY = "documentary";
    const USER = "user";
}